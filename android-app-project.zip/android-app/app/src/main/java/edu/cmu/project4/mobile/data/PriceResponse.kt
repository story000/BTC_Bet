package edu.cmu.project4.mobile.data

data class PriceResponse(
    val symbol: String,
    val price: String,
    val fetchedAt: String
)
